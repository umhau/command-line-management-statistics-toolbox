from .histogram import plot_hist
from .scatterplot import plot_scatter
from .barplot import plot_bar